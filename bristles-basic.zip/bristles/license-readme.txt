Forks And Drills
Brush Set for Gimp [2012]

---
Author: Jose Americo Gobbo [http://americogobbo.com.br]
Co-author and testing: Mozart Couto [http://blogdodesenhador.blogspot.com.br/]
License: GPL 3.0

If you pretend one brush or a series to do part of others collections or packs, please contact us through our websites! And don't forget that you need make mention our names in this collection or pack.
Thanks.

--
Main note
The series is made thinking mainly on specific techniques... but is possible to obtain other techniques with the tips of Mozart (opacity, scale and spacing, all gimp features).
In many of these series I've created simplified versions of the dynamics brushes (a static brush version)... thinking the possibility to use with the new gimp dynamic features. I think interesting to understand well what these dynamics are capable to do... in many cases is possible simplify the process using only a static brush with a dynamic matrix to emulate some gih brushes... mainly where these brushes have a stain or a stroke that is the same in all layers of the gih brush.
