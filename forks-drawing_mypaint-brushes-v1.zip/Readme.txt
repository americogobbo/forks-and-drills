Forks And Drills
Brush Set for Drawing on MyPaint [2013]

---
Author: Jose Americo Gobbo [http://americogobbo.com.br]
License: GPL 3.0

If you pretend one brush or a series to do part of others collections or packs, please contact us through our websites! And don't forget that you need make mention our names in this collection or pack.
Thanks.

--
Main note
The series is made thinking mainly on specific drawing techniques. The rapidograph are very simple and they're made with a standard and linear curve for pressure.

==
Forks Rapidograph pen 0.2, 0.4, 0.8, 1.0 and 2.0 mm Series
forks-jag_pen-0.2.myb
forks-jag_pen-0.4.myb
forks-jag_pen-0.8.myb
forks-jag_pen-1.0.myb
forks-jag_pen-2.0.myb
==
Forks Pencils hard, soft and wet colors Series
forks-jag_hard-pencil.myb
forks-jag_blackness-pencil.myb
forks-jag_soft-pencil.myb
forks-jag_sketch-brushpen.myb
forks-jag_penbrush.myb



