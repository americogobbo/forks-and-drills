Forks And Drills Brush Set for Gimp
--
Author: Jose Americo Gobbo
License: GPL 3.0

--
Doodle Series
All brushes in this series are thought to emulate dry media, like pencil, graphite, etc.
But is possible to obtain other techniques with the tips of Mozart (opacity, scale and spacing, all gimp features).

--
Dry Brush Series
The Dry Brush Series was thought to emulate many kind of dry brushes.
But is possible to obtain other techniques with the tips of Mozart (opacity, scale and spacing, all gimp features).

--
Flower Series
All brushes in this series are thought to make patterns and textures.
But is possible to obtain other techniques with the tips of Mozart (opacity, scale and spacing, all gimp features).

--
Metabrush Series
All brushes in this series are thought to make many techniques, that is motif of the name.
But is possible to obtain other techniques with the tips of Mozart (opacity, scale and spacing, all gimp features).

--
Watercolor Series
The Watercolors Series was thought to emulate many of the aspect of that technique.
But is possible to obtain other techniques with the tips of Mozart (opacity, scale and spacing, all gimp features).

--
Watercolor Series [Grain Series]
The Watercolors Series was thought to emulate many of the aspect of that technique.
In this case the brushes are formed of small grains of tint.
But is possible to obtain other techniques with the tips of Mozart (opacity, scale and spacing, all gimp features).

Thanks to Mozart Couto that has made the tests in my collection.
