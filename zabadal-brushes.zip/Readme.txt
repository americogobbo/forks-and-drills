Zabadal classical technique

1. Forks | Drypoint 1
2. Forks | Drypoint 2
--
4. Forks | Litographic Chalk 1
5. Forks | Litographic Chalk 2
6. Forks | Litographic Chalk 3
7. Forks | Litographic Chalk 3
--
8. Forks | Red Chalk 1
9. Forks | Red Chalk 2
10. Forks | Red Chalk 3
--
11. Forks | Round Brush 2
12. Forks | Round Brush 3
13. Forks | Round Brush 4
--
14. Forks | Woodcut 1
15. Forks | Woodcut 2
16. Forks | Woodcut 3
17. Forks | Woodcut 4
18. Forks | Woodcut 5
19. Forks | Woodcut 6
20. Forks | Woodcut 7
